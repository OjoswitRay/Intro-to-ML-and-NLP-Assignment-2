
import torch
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset, load_metric
from sklearn.metrics import accuracy_score, f1_score
from transformers import DataCollatorWithPadding
import numpy as np
import os


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


raw_datasets = load_dataset("imdb")


model_name = "bert-base-uncased"
tokenizer = BertTokenizer.from_pretrained(model_name)


def tokenize_function(example):
    return tokenizer(example["text"], truncation=True)


tokenized_datasets = raw_datasets.map(tokenize_function, batched=True)


train_dataset = tokenized_datasets["train"]
test_dataset = tokenized_datasets["test"]


data_collator = DataCollatorWithPadding(tokenizer=tokenizer)


model = BertForSequenceClassification.from_pretrained(model_name, num_labels=2)
model.to(device)


def compute_metrics(eval_pred):
    logits, labels = eval_pred
    predictions = np.argmax(logits, axis=1)
    acc = accuracy_score(labels, predictions)
    f1 = f1_score(labels, predictions)
    return {"accuracy": acc, "f1": f1}

training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="epoch",
    save_strategy="epoch",
    logging_dir="./logs",
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    num_train_epochs=2,
    save_total_limit=1,
    load_best_model_at_end=True,
    metric_for_best_model="accuracy"
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
    tokenizer=tokenizer,
    data_collator=data_collator,
    compute_metrics=compute_metrics
)

trainer.train()

eval_results = trainer.evaluate()
print("Evaluation Results:", eval_results)

model_dir = "./sentiment-bert"
model.save_pretrained(model_dir)
tokenizer.save_pretrained(model_dir)

def predict_sentiment(text):

    model = BertForSequenceClassification.from_pretrained(model_dir)
    tokenizer = BertTokenizer.from_pretrained(model_dir)
    model.to(device)
    model.eval()

    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True).to(device)
    with torch.no_grad():
        outputs = model(**inputs)
    logits = outputs.logits
    predicted_class_id = torch.argmax(logits).item()
    return "Positive" if predicted_class_id == 1 else "Negative"

sample_text = "The movie was absolutely wonderful, with great acting!"
print("Sample Prediction:", predict_sentiment(sample_text))
